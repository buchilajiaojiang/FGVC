import random

import torch
from torch.optim import lr_scheduler
from torchvision import transforms
from torch.utils.data import Dataset, DataLoader
from PIL import Image
import json
import numpy as np
import torch.nn as nn
from datetime import datetime
import os
import torch.distributed as dist
from torch.nn.parallel import DistributedDataParallel as DDP
from torch.utils.data import DataLoader, DistributedSampler
from torch.utils.tensorboard import SummaryWriter

from models.model_group_api_lsk_encoder import Net, RegularLoss
from dataset import BaseDataset


current_dir = os.path.dirname(os.path.abspath(__file__))
root_dir = os.path.abspath(os.path.join(current_dir, "./"))

def setup_distributed():
    """
    初始化分布式训练环境
    """
    os.environ['CUDA_VISIBLE_DEVICES'] = '0,1,2'
    torch.distributed.init_process_group(backend="nccl")
    local_rank = torch.distributed.get_rank()
    torch.cuda.set_device(local_rank)
    device = torch.device("cuda", local_rank)
    return local_rank

def get_loader(num_classes, bs, shuffle, drop_last, workers, dataset_type, dataset_name, img_size=448):
    dataset = BaseDataset(num_classes=num_classes, data_type=dataset_type, img_size=img_size, dataset_name=dataset_name)
    sampler = DistributedSampler(dataset, shuffle=shuffle)
    # train
    loader = DataLoader(dataset=dataset,sampler=sampler, num_workers=workers, batch_size=bs, drop_last=drop_last)
    return loader


def evaluate(model, test_loader, epoch):
    model.eval()
    test_loader.sampler.set_epoch(epoch)
    
    correct = 0
    total = 0
    with torch.no_grad():
        for img, lab in test_loader:
            img, lab = img.cuda(), lab.cuda()
            outputs = model(img, flag='val')
            # sum_outputs = torch.sum(torch.stack(outputs), dim=0)
            _, predicted = torch.max(outputs.data, 1)
            total += lab.size(0)
            # print(f"label.shape:{lab.shape}, logits.shape={logits.shape}")
            correct += (predicted == lab).sum().item()
            # print(f"total = {total}, correct = {correct}")
    acc = 100 * correct / total
    return acc


def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    
def calculate_pooling_center_loss(features, centers, label, alfa=0.95):
    # centers = model.centers
    # print('111111111',sum(sum(centers)))
    # mse_loss = torch.nn.MSELoss()
    features = features.reshape(features.shape[0], -1)
    # print(features.shape)
    centers_batch = centers[label]
    # print(centers_batch)
    # print(centers_batch.shape,centers.shape)
    centers_batch = torch.nn.functional.normalize(centers_batch, dim=-1)
    diff =  (1-alfa)*(features.detach() - centers_batch)
    distance = torch.pow(features - centers_batch,2)
    distance = torch.sum(distance, dim=-1)
    center_loss = torch.mean(distance)
    # loss2 = mse_loss(features,centers_batch)
    # print('================',center_loss.item(),loss2.item())
    return center_loss, diff

def init_crossx_params():
    # gamma1 = 0.5  # 0.35
    # gamma2 = 0.5  # 0.3
    # gamma3 = 1  # 0.35
    gamma1 = 1 # last 0.35
    gamma2 = 0.3 # last 0.3  优先降值
    return gamma1, gamma2

# torchrun --nproc_per_node=3 use_dis_train_encoder.py
# torchrun --nproc_per_node=1 use_dis_train_encoder.py
if __name__ == "__main__":
    local_rank = setup_distributed()
    set_seed(42)
    # model_name =
    print('-' * 30)
    dataset_config = {0: "Accessorites"}
    print(dataset_config)
    dataset_name = dataset_config[0]
    print('-' * 30)
    model_name = 'GroupC3S_API_change_4'
    print(model_name)
    print('-' * 30)
    
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    # 当使用adamw时，需使用lre-4和-5
    # 新数据集18个类
    configs = {
        "num_classes": 18, "img_size": 448, "lr": 1e-4, "epoch": 100, 
        "train": {"workers": 3, "bs": 16, "shuffle": True, "drop_last": False},
        "test": {"workers": 0, "bs": 16, "shuffle": False, "drop_last": False},
        "valid": {"workers": 0, "bs": 16, "shuffle": False, "drop_last": False}
    }

    train_loader = get_loader(
        num_classes=configs["num_classes"],
        bs=configs["train"]["bs"],
        shuffle=configs["train"]["shuffle"],
        drop_last=configs["train"]["drop_last"],
        workers=configs["train"]["workers"],
        dataset_type="train",
        img_size=configs["img_size"],
        dataset_name=dataset_name
    )

    test_loader = get_loader(
        num_classes=configs["num_classes"],
        bs=configs["test"]["bs"],
        shuffle=configs["test"]["shuffle"],
        drop_last=configs["test"]["drop_last"],
        workers=configs["test"]["workers"],
        dataset_type="test",
        img_size=configs["img_size"],
        dataset_name=dataset_name
    )

    # 3. Resnet101
    # net = Net(num_classes=configs["num_classes"], num_groups=4).cuda()
    net = Net(num_classes=configs["num_classes"], num_groups=4).cuda()
    # net = torch.nn.DataParallel(net)
    # net = DDP(net, device_ids=[local_rank], output_device=local_rank)  # 封装为分布式模型
    net = torch.nn.parallel.DistributedDataParallel(net,find_unused_parameters=True)

    lr, momentum, decay_step, weight_decay = configs["lr"], 0.9, 75, 0.01 # 1e-4
    # optimizer = torch.optim.SGD(lr=lr, momentum=momentum, weight_decay=weight_decay, params=net.parameters())
    optimizer = torch.optim.AdamW(net.parameters(), lr=lr, weight_decay=weight_decay)  # AdamW优化器

    # scheduler = lr_scheduler.StepLR(optimizer, step_size=decay_step, gamma=0.1) # 300epochs 160epoch下降0.1
    scheduler = lr_scheduler.MultiStepLR(optimizer, milestones=[25,80], gamma=0.1, last_epoch=-1) # [5,80,120,140]
    # scheduler_fc = torch.optim.lr_scheduler.CosineAnnealingLR(
    #     optimizer, configs["epoch"] * len(train_loader))
    
    nparts = 4
    
    gamma1, gamma2 = init_crossx_params()
    # reg_loss_group1 = RegularLoss(gamma=gamma1, nparts=2)
    reg_loss_group2 = RegularLoss(gamma=gamma2, nparts=nparts)
    criterion = nn.CrossEntropyLoss()
    
    rank_criterion = nn.MarginRankingLoss(margin=0.05)
    softmax_layer = nn.Softmax(dim=1).to(device)
    now = datetime.now()
    
    center = torch.zeros(configs["num_classes"], 2048).cuda()
    acc_best = {"acc": 0, "epoch": 0}
    
    rank = int(os.environ["RANK"])
    if rank == 0:
        current_date = datetime.now().strftime("%Y%m%d")
        current_time = datetime.now().strftime("%H%M")
        writer = SummaryWriter(log_dir= f"./logs/{current_date}_{current_time}_encoder") # tensorboard --logdir=./logs
    
    
    for epoch in range(0, configs["epoch"], 1):
        running_loss = 0.0
        correct = 0
        total = 0
        # 验证
        if epoch % 1 == 0:
            accuracy = evaluate(model=net, test_loader=test_loader, epoch=epoch)
            if rank == 0:
                print(" ---------------- Test ACC ----------------")
                print(f"epoch:{epoch} The accuracy is:{accuracy}")
                writer.add_scalar('Accuracy/test', accuracy, epoch)
            if accuracy > acc_best["acc"]:
                acc_best["acc"] = accuracy
                acc_best["epoch"] = epoch
                if rank == 0:
                    model_path = os.path.join(
                        root_dir, "save", "model", model_name,
                        "epoch_" + str(epoch) + "_acc_" + str(round(accuracy, 3)) + ".pth")
                    torch.save(net.state_dict(), model_path)
            if rank == 0:
                print(" ---------------- ACC ----------------")
                print(f"The best is:{acc_best}, appear in epoch:{acc_best['epoch']}")

        net.train(True)
        train_loader.sampler.set_epoch(epoch)
        
        current_lr = optimizer.param_groups[0]['lr']
        print("Epoch: ", epoch, "Current learning rate: ", current_lr)
        
        for batch_cnt, batch in enumerate(train_loader):
            image, label = batch[0].cuda(), torch.LongTensor(batch[1]).cuda()
            optimizer.zero_grad()
            logit_all  = net(image) # len nparts*nparts
            
            labels1 = label
            labels2 = label
            
            batch_size = logit_all[0].shape[0]
            
            loss = criterion(logit_all, label)
            
            all_loss = loss
            all_loss.backward()
            
            optimizer.step()
            # if epoch % decay_step == 0 and epoch != 0:
            
            running_loss += loss.item()
            _, predicted = torch.max(logit_all.data, 1)
            total += label.size(0)
            correct += predicted.eq(label).sum().item()
            if rank == 0:
                if batch_cnt % 100 == 0:
                    step = epoch * len(train_loader) + batch_cnt
                    writer.add_scalar('Loss/train', running_loss / (batch_cnt + 1), step)
                    writer.add_scalar('Accuracy/train', 100 * correct / total, step)
                    
                if batch_cnt % 10 == 0:
                    now = datetime.now()
                    print(now.strftime("%Y-%m-%d %H:%M:%S"))
                    print(f"epoch = {epoch}, iteration: {batch_cnt},all loss: {all_loss.item()} label loss: {loss.item()}")
        
        if rank == 0:
            train_loss = running_loss / len(train_loader)
            train_acc = correct / total
            print(f"Train Epoch {epoch}: Accuracy: {100. * train_acc:.2f}% Train Loss: {train_loss:.6f}")
    
        scheduler.step()
    if rank == 0:
        writer.close()
    dist.destroy_process_group()


# torchrun  --nproc_per_node=1 2.py --batchSize 64 --epochs 10 --gpu_id 0