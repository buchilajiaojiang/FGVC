import random
import torch
from torch.optim import lr_scheduler
from torchvision import transforms
from torch.utils.data import Dataset, DataLoader
from PIL import Image
import json
import numpy as np
import torch.nn as nn
from datetime import datetime
import os

from GroupNet import Net

current_dir = os.path.dirname(os.path.abspath(__file__))
root_dir = os.path.abspath(os.path.join(current_dir, "./"))

# --------------------------- 数据集定义 ---------------------------
class FashionAIDataset(Dataset):
    def __init__(self, num_classes, data_type, img_size, dataset_name):
        self.img_path = os.path.join(root_dir, 'all_data', dataset_name, data_type, "image")
        self.label_path = os.path.join(root_dir, 'all_data', dataset_name, data_type, "label", "label.json")
        print("Image path:", self.img_path)
        print("Label path:", self.label_path)
        self.labels = json_reader(self.label_path)
        self.len = len(self.labels)
        self.num_classes = num_classes

        if data_type == "train":
            self.transform = transforms.Compose([
                transforms.RandomVerticalFlip(0.5),
                transforms.RandomHorizontalFlip(0.5),
                transforms.Resize((img_size, img_size)),
                transforms.ToTensor(),
                transforms.Normalize([0.485, 0.456, 0.406],
                                     [0.229, 0.224, 0.225])
            ])
        else:
            self.transform = transforms.Compose([
                transforms.Resize((img_size, img_size)),
                transforms.ToTensor(),
                transforms.Normalize([0.485, 0.456, 0.406],
                                     [0.229, 0.224, 0.225])
            ])

    def __getitem__(self, idx):
        label_item = self.labels[idx]
        image_path = os.path.join(self.img_path, label_item[0])
        image = Image.open(image_path).convert("RGB")
        image = self.transform(image)
        return image, label_item[1]

    def __len__(self):
        return self.len

def json_reader(label_path):
    with open(label_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    return data

def get_loader(num_classes, bs, shuffle, drop_last, workers, dataset_type, dataset_name, img_size=448):
    dataset = FashionAIDataset(num_classes=num_classes, data_type=dataset_type,
                               img_size=img_size, dataset_name=dataset_name)
    loader = DataLoader(dataset=dataset, num_workers=workers,
                        batch_size=bs, shuffle=shuffle, drop_last=drop_last)
    return loader

# ----------------------- 评估函数 -----------------------
def evaluate(model, test_loader):
    model.eval()
    correct = 0
    total = 0
    with torch.no_grad():
        for img, lab in test_loader:
            img, lab = img.cuda(), lab.cuda()
            outputs = model(img)  # 模型返回 logits
            _, predicted = torch.max(outputs.data, 1)
            total += lab.size(0)
            correct += (predicted == lab).sum().item()
    return 100 * correct / total if total > 0 else 0

def evaluate_train(model, train_loader):
    model.eval()
    correct = 0
    total = 0
    with torch.no_grad():
        for img, lab in train_loader:
            img, lab = img.cuda(), lab.cuda()
            outputs = model(img)
            _, predicted = torch.max(outputs.data, 1)
            total += lab.size(0)
            correct += (predicted == lab).sum().item()
    return 100 * correct / total if total > 0 else 0

# ----------------------- 工具函数 -----------------------
def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)

# 中心损失函数：计算 raw_features 与对应类别中心之间的欧氏距离平方
def calculate_pooling_center_loss(features, centers, labels, alfa=0.95):
    features = features.reshape(features.shape[0], -1)
    centers_batch = centers[labels]
    centers_batch = torch.nn.functional.normalize(centers_batch, dim=-1)
    diff = (1 - alfa) * (features.detach() - centers_batch)
    distance = torch.pow(features - centers_batch, 2)
    distance = torch.sum(distance, dim=-1)
    center_loss = torch.mean(distance)
    return center_loss, diff

# ----------------------- 主训练流程 -----------------------
net_maker = {
    'GroupNet': Net,
}

if __name__ == "__main__":
    set_seed(42)
    print('-' * 30)
    dataset_config = {0: "collar", 1: "contour", 2: "fabric", 3: "sleeve_type" , 4:"gender" ,5:"clothes_length",}
    print("Dataset config:", dataset_config)
    dataset_name = dataset_config[int(input("Which dataset needs to be trained?\n"))]
    print('-' * 30)
    model_config = {0: "GroupNet"}
    print("Model config:", model_config)
    model_name = model_config[int(input("Which model needs to be trained?\n"))]
    print('-' * 30)
    configs = {
        "num_classes": 13,
        "img_size": 448,
        "lr": 1e-2,
        "epoch": 300,
        "train": {"workers": 4, "bs": 32, "shuffle": True, "drop_last": False},
        "test": {"workers": 0, "bs": 32, "shuffle": False, "drop_last": False},
    }

    train_loader = get_loader(num_classes=configs["num_classes"],
                              bs=configs["train"]["bs"],
                              shuffle=configs["train"]["shuffle"],
                              drop_last=configs["train"]["drop_last"],
                              workers=configs["train"]["workers"],
                              dataset_type="train",
                              img_size=configs["img_size"],
                              dataset_name=dataset_name)

    test_loader = get_loader(num_classes=configs["num_classes"],
                             bs=configs["test"]["bs"],
                             shuffle=configs["test"]["shuffle"],
                             drop_last=configs["test"]["drop_last"],
                             workers=configs["test"]["workers"],
                             dataset_type="test",
                             img_size=configs["img_size"],
                             dataset_name=dataset_name)

    net = net_maker[model_name](num_classes=configs["num_classes"], num_groups=4).cuda()
    net = torch.nn.DataParallel(net)

    # 注册hook：捕获 net.module.avg 层的输出作为中间特征（未经过 flatten）
    raw_feature_container = {}
    def hook_fn(module, input, output):
        raw_feature_container['avg_out'] = output
    net.module.avg.register_forward_hook(hook_fn)

    optimizer = torch.optim.SGD(net.parameters(), lr=configs["lr"], momentum=0.9, weight_decay=1e-5)
    scheduler = lr_scheduler.StepLR(optimizer, step_size=160, gamma=0.1)
    criterion = nn.CrossEntropyLoss()

    # 用一个 dummy 输入运行一次，获取 raw_features 的维度
    dummy = torch.randn(1, 3, configs["img_size"], configs["img_size"]).cuda()
    _ = net(dummy)  # 前向传播触发 hook
    dummy_raw = net.module.flatten(raw_feature_container['avg_out'])
    feature_dim = dummy_raw.shape[1]
    center = torch.zeros(configs["num_classes"], feature_dim).cuda()

    acc_best = {"acc": 0, "epoch": 0}
    for epoch in range(configs["epoch"]):
        train_acc = evaluate_train(net, train_loader)
        test_acc = evaluate(net, test_loader)
        if test_acc > acc_best["acc"]:
            acc_best["acc"] = test_acc
            acc_best["epoch"] = epoch
            model_path = os.path.join(root_dir, "save", "model", model_name,
                                      f"epoch_{epoch}_acc_{round(test_acc, 3)}.pth")
            os.makedirs(os.path.dirname(model_path), exist_ok=True)
            torch.save(net.state_dict(), model_path)
        print(" ---------------- ACC ----------------")
        print(f"Epoch: {epoch}, Train Acc: {train_acc:.2f}%, Test Acc: {test_acc:.2f}%")
        print(f"The best so far: {acc_best}, appear in epoch: {acc_best['epoch']}")

        net.train(True)
        current_lr = optimizer.param_groups[0]['lr']
        print("Epoch: ", epoch, "Current learning rate: ", current_lr)
        for batch_cnt, batch in enumerate(train_loader):
            image, label = batch[0].cuda(), torch.LongTensor(batch[1]).cuda()
            optimizer.zero_grad()
            # 前向传播：模型返回 logits（不包含 raw_features）
            logits = net(image)
            # 通过hook捕获的 self.avg 输出，经过 flatten 得到 raw_features
            raw_features = net.module.flatten(raw_feature_container['avg_out'])
            loss_ce = criterion(logits, label)
            center_loss, center_diff = calculate_pooling_center_loss(raw_features, center, label, alfa=0.95)
            total_loss = loss_ce + center_loss
            total_loss.backward()
            optimizer.step()
            # 更新center（不参与梯度传播）
            center[label] += center_diff

            if batch_cnt % 10 == 0:
                now = datetime.now()
                print(now.strftime("%Y-%m-%d %H:%M:%S"))
                print(f"Epoch = {epoch}, Iteration: {batch_cnt}, Total Loss: {total_loss.item():.4f}, "
                      f"CE Loss: {loss_ce.item():.4f}, Center Loss: {center_loss.item():.4f}")
        scheduler.step()
