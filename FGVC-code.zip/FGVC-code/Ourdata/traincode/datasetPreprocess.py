import os
import json
import shutil
import random

def custom_json_dump(data, f):
    """
    将 data（列表，每个元素为 [filename, label]）写入文件 f，
    格式为每行输出两个内层列表。
    """
    f.write("[\n")
    # 按两个一组输出
    for i in range(0, len(data), 2):
        if i + 1 < len(data):
            line = "  " + json.dumps(data[i], ensure_ascii=False) + ", " + json.dumps(data[i+1], ensure_ascii=False)
        else:
            line = "  " + json.dumps(data[i], ensure_ascii=False)
        if i + 2 < len(data):
            line += ",\n"
        else:
            line += "\n"
        f.write(line)
    f.write("]")

def prepare_dataset(
    input_dir,           # 原始图片所在目录，包含形如 "collar-一字领-232262.jpg"
    output_root,         # 目标根目录: "E:/计算机视觉模型/Ourdateset/all_data/collar"
    train_ratio=0.7,     # 训练集比例
    seed=42
):
    """
    将 input_dir 下的图片按 train:test = train_ratio:(1-train_ratio) 拆分到:
      output_root/train/image
      output_root/train/label
      output_root/test/image
      output_root/test/label
    并在 label 文件夹写入 label.json。

    label.json 的结构与示例一致，比如:
    [
      ["xxx.jpg",6], ["yyy.jpg",0],
      ...
    ]
    每行输出两个内层列表。
    """
    random.seed(seed)

    # 1) 扫描文件并解析类别
    samples = []
    for filename in os.listdir(input_dir):
        if not filename.lower().endswith(('.jpg', '.jpeg', '.png', '.bmp')):
            continue
        parts = filename.split('-')
        if len(parts) < 3:
            continue
        # 取第二段作为类别
        class_name = parts[1]
        samples.append((filename, class_name))

    if not samples:
        print("未找到符合命名规则的图像，请检查 input_dir:", input_dir)
        return

    # 2) 建立类别->数字索引映射
    all_class_names = sorted(list(set(s[1] for s in samples)))
    class_to_idx = {cls_name: idx for idx, cls_name in enumerate(all_class_names)}
    print("解析到的类别->标签索引:", class_to_idx)

    # 3) 数据拆分
    random.shuffle(samples)
    total_count = len(samples)
    train_count = int(total_count * train_ratio)
    train_samples = samples[:train_count]
    test_samples = samples[train_count:]
    print(f"总计 {total_count} 张, 训练集 {len(train_samples)} 张, 测试集 {len(test_samples)} 张")

    # 4) 构造输出路径
    train_image_dir = os.path.join(output_root, "train", "image")
    train_label_dir = os.path.join(output_root, "train", "label")
    test_image_dir = os.path.join(output_root, "test", "image")
    test_label_dir = os.path.join(output_root, "test", "label")

    os.makedirs(train_image_dir, exist_ok=True)
    os.makedirs(train_label_dir, exist_ok=True)
    os.makedirs(test_image_dir, exist_ok=True)
    os.makedirs(test_label_dir, exist_ok=True)

    # 5) 复制图片到对应文件夹，并生成 [filename, label]
    train_list = []
    for fname, cls_name in train_samples:
        src_path = os.path.join(input_dir, fname)
        dst_path = os.path.join(train_image_dir, fname)
        shutil.copy(src_path, dst_path)
        label_id = class_to_idx[cls_name]
        train_list.append([fname, label_id])

    test_list = []
    for fname, cls_name in test_samples:
        src_path = os.path.join(input_dir, fname)
        dst_path = os.path.join(test_image_dir, fname)
        shutil.copy(src_path, dst_path)
        label_id = class_to_idx[cls_name]
        test_list.append([fname, label_id])

    # 6) 将结果写入 label.json，使用自定义格式，每行输出两个内层列表
    train_label_path = os.path.join(train_label_dir, "label.json")
    with open(train_label_path, 'w', encoding='utf-8') as f:
        custom_json_dump(train_list, f)

    test_label_path = os.path.join(test_label_dir, "label.json")
    with open(test_label_path, 'w', encoding='utf-8') as f:
        custom_json_dump(test_list, f)

    print("训练集标签已写到:", train_label_path)
    print("测试集标签已写到:", test_label_path)

if __name__ == "__main__":
    input_folder = r"/data0/WH-FGVC/our_data/Ourdataset/all_data/contour"
    output_folder = r"/data0/WH-FGVC/our_data/Ourdataset/all_data/contour"

    prepare_dataset(
        input_dir=input_folder,
        output_root=output_folder,
        train_ratio=0.7,
        seed=42
    )
