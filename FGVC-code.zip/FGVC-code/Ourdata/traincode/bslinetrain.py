import random
import torch
from torch.optim import lr_scheduler
from torchvision import transforms
from torch.utils.data import Dataset, DataLoader
from PIL import Image
import json
import numpy as np
import torch.nn as nn
from datetime import datetime
import os

from GroupNet import Net
from models import ResNet50, Vgg, Alex_Net

current_dir = os.path.dirname(os.path.abspath(__file__))
root_dir = os.path.abspath(os.path.join(current_dir, "./"))

# ----------------------------------------Dataset----------------------------------------
class FashionAIDataset(Dataset):
    def __init__(self, num_classes, data_type, img_size, dataset_name):
        self.img_path = os.path.join(root_dir, 'all_data', dataset_name, data_type, "image")
        self.label_path = os.path.join(root_dir, 'all_data', dataset_name, data_type, "label", "label.json")
        print("Image path:", self.img_path)
        print("Label path:", self.label_path)
        self.labels = json_reader(self.label_path)
        self.len = len(self.labels)
        self.num_classes = num_classes

        if data_type == "train":
            # 数据增强：垂直反转、随机水平翻转、Resize、ToTensor、Normalize
            self.transform = transforms.Compose([
                transforms.RandomVerticalFlip(0.5),
                transforms.RandomHorizontalFlip(0.5),
                transforms.Resize((img_size, img_size)),
                transforms.ToTensor(),
                transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
            ])
        else:
            # 验证集/测试集不进行数据增强
            self.transform = transforms.Compose([
                transforms.Resize((img_size, img_size)),
                transforms.ToTensor(),
                transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
            ])

    def __getitem__(self, idx):
        label_item = self.labels[idx]
        image_path = os.path.join(self.img_path, label_item[0])
        # 使用 .convert("RGB") 确保图片为RGB格式
        image = Image.open(image_path).convert("RGB")
        image = self.transform(image)
        return image, label_item[1]

    def __len__(self):
        return self.len

def json_reader(label_path):
    # 直接读取整个 JSON 文件，返回列表数据
    with open(label_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    return data

# loader数据加载器
def get_loader(num_classes, bs, shuffle, drop_last, workers, dataset_type, dataset_name, img_size=448):
    dataset = FashionAIDataset(num_classes=num_classes, data_type=dataset_type, img_size=img_size, dataset_name=dataset_name)
    loader = DataLoader(dataset=dataset, num_workers=workers, batch_size=bs, shuffle=shuffle, drop_last=drop_last)
    return loader

# 模型评估函数（测试集）
def evaluate(model, test_loader):
    model.eval()
    correct = 0
    total = 0
    with torch.no_grad():
        for img, lab in test_loader:
            img, lab = img.cuda(), lab.cuda()
            outputs = model(img)
            _, predicted = torch.max(outputs.data, 1)
            total += lab.size(0)
            correct += (predicted == lab).sum().item()
    acc = 100 * correct / total if total > 0 else 0
    return acc

# 模型评估函数（训练集）
def evaluate_train(model, train_loader):
    model.eval()
    correct = 0
    total = 0
    with torch.no_grad():
        for img, lab in train_loader:
            img, lab = img.cuda(), lab.cuda()
            outputs = model(img)
            _, predicted = torch.max(outputs.data, 1)
            total += lab.size(0)
            correct += (predicted == lab).sum().item()
    acc = 100 * correct / total if total > 0 else 0
    return acc

# 设置随机种子以确保实验的可复现性
def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)

net_maker = {
    'GroupNet': Net,
    'Resnet50': ResNet50,
    'Vgg': Vgg,
    'Alexnet': Alex_Net,
}

if __name__ == "__main__":
    set_seed(42)
    print('-' * 30)
    dataset_config = {0: "collar",  1:"contour",  2:"fabric",   3:"sleeve_type" ,   }
    print("Dataset config:", dataset_config)
    dataset_name = dataset_config[int(input("Which dataset needs to be trained?\n"))]
    print('-' * 30)
    model_config = {0: "GroupNet", 1: "Resnet50", 2: "Vgg", 3: "Alexnet"}
    print("Model config:", model_config)
    model_name = model_config[int(input("Which model needs to be trained?\n"))]
    print('-' * 30)
    configs = {
        "num_classes": 13,
        "img_size": 448,
        "lr": 1e-2,  # 保持 SGD，学习率不变
        "epoch": 300,
        "train": {"workers": 4, "bs": 32, "shuffle": True, "drop_last": False},
        "test": {"workers": 0, "bs": 32, "shuffle": False, "drop_last": False},
        "valid": {"workers": 0, "bs": 32, "shuffle": False, "drop_last": False}
    }

    train_loader = get_loader(
        num_classes=configs["num_classes"],
        bs=configs["train"]["bs"],
        shuffle=configs["train"]["shuffle"],
        drop_last=configs["train"]["drop_last"],
        workers=configs["train"]["workers"],
        dataset_type="train",
        img_size=configs["img_size"],
        dataset_name=dataset_name
    )

    test_loader = get_loader(
        num_classes=configs["num_classes"],
        bs=configs["test"]["bs"],
        shuffle=configs["test"]["shuffle"],
        drop_last=configs["test"]["drop_last"],
        workers=configs["test"]["workers"],
        dataset_type="test",
        img_size=configs["img_size"],
        dataset_name=dataset_name
    )

    net = net_maker[model_name](num_classes=configs["num_classes"]).cuda()
    net = torch.nn.DataParallel(net)

    # 使用 SGD 优化器，保持原设置
    lr_val, momentum, decay_step, weight_decay = configs["lr"], 0.9, 160, 1e-5
    optimizer = torch.optim.SGD(lr=lr_val, momentum=momentum, weight_decay=weight_decay, params=net.parameters())
    scheduler = lr_scheduler.StepLR(optimizer, step_size=decay_step, gamma=0.1)
    criterion = nn.CrossEntropyLoss()

    acc_best = {"acc": 0, "epoch": 0}
    for epoch in range(configs["epoch"]):
        # 每个 epoch 开始前评估训练集与测试集
        train_acc = evaluate_train(net, train_loader)
        test_acc = evaluate(net, test_loader)
        if test_acc > acc_best["acc"]:
            acc_best["acc"] = test_acc
            acc_best["epoch"] = epoch
            model_path = os.path.join(
                root_dir, "save", "model", model_name,
                f"epoch_{epoch}_acc_{round(test_acc, 3)}.pth")
            torch.save(net.state_dict(), model_path)
        print(" ---------------- ACC ----------------")
        print(f"Epoch: {epoch}, Train Acc: {train_acc:.2f}%, Test Acc: {test_acc:.2f}%")
        print(f"The best so far: {acc_best}, appear in epoch: {acc_best['epoch']}")

        net.train(True)
        current_lr = optimizer.param_groups[0]['lr']
        print("Epoch: ", epoch, "Current learning rate: ", current_lr)
        for batch_cnt, batch in enumerate(train_loader):
            image, label = batch[0].cuda(), torch.LongTensor(batch[1]).cuda()
            optimizer.zero_grad()
            logits = net(image)
            loss = criterion(logits, label)
            loss.backward()
            optimizer.step()
            if batch_cnt % 10 == 0:
                now = datetime.now()
                print(now.strftime("%Y-%m-%d %H:%M:%S"))
                print(f"Epoch = {epoch}, Iteration: {batch_cnt}, Loss: {loss.item()}")
        scheduler.step()
