import torch
torch.cuda.empty_cache()