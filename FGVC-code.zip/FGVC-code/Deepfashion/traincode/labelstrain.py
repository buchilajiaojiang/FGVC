import os
import random
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms, models
from PIL import Image

#############################
# 1. 配置 (Config)
#############################
current_dir = os.path.dirname(os.path.abspath(__file__))
root_dir = os.path.abspath(os.path.join(current_dir, "./"))

class Config:
    data_root = os.path.join(root_dir, 'Img')  # 图片根目录
    train_list = os.path.join(root_dir, 'Anno_fine', "train.txt")  # 训练集图片路径
    test_list = os.path.join(root_dir, 'Anno_fine', "test.txt")  # 测试集图片路径
    val_list = os.path.join(root_dir, 'Anno_fine', "val.txt")  # 验证集图片路径
    # 标签文件：多标签时每行应有26个数字；若每行只有一个类别，则在数据集中转换为 one-hot（长度26）
    train_labels = os.path.join(root_dir, 'Anno_fine', "train_attr.txt")
    test_labels = os.path.join(root_dir, 'Anno_fine', "test_attr.txt")
    val_labels = os.path.join(root_dir, 'Anno_fine', "val_attr.txt")
    batch_size = 32
    num_workers = 4
    img_size = 448
    lr = 0.001  # 学习率
    epochs = 300
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    # 6 组属性的索引范围(左闭右开)
    group_splits = {
        "Group1": [(0, 7)],   # 0..6
        "Group2": [(7, 10)],  # 7..9
        "Group3": [(10, 13)], # 10..12
        "Group4": [(13, 17)], # 13..16
        "Group5": [(17, 23)], # 17..22
        "Group6": [(23, 26)]  # 23..25
    }

config = Config()

# 数据增强策略
train_transform = transforms.Compose([
    transforms.RandomResizedCrop(224),
    transforms.RandomHorizontalFlip(),
    transforms.ToTensor(),
    transforms.Normalize([0.485, 0.456, 0.406],
                         [0.229, 0.224, 0.225])
])

val_transform = transforms.Compose([
    transforms.Resize(256),
    transforms.CenterCrop(224),
    transforms.ToTensor(),
    transforms.Normalize([0.485, 0.456, 0.406],
                         [0.229, 0.224, 0.225])
])

#############################
# 2. 设置随机种子
#############################
def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)

#############################
# 3. 定义模型构造函数
#############################
def ResNet50(num_classes=26):
    """
    使用 torchvision 的 ResNet50，并将最后一层修改为输出 26 个类别
    """
    model = models.resnet50(pretrained=True)
    in_features = model.fc.in_features
    model.fc = nn.Linear(in_features, num_classes)
    return model

# 利用 net_maker 字典管理所有可选模型
net_maker = {
    'ResNet50': ResNet50,
}

#############################
# 4. 数据集定义
#############################
class FashionAttrDataset(Dataset):
    """
    假设：
      - list_file 每行是一张图片的相对路径；
      - attr_file 每行对应该图片的 26 维标签，或者只有一个类别索引（此时转换为 one-hot 向量）。
      两个文件行数一一对应。
    """
    def __init__(self, list_file, attr_file, transform=None):
        super().__init__()
        with open(list_file, 'r') as f:
            self.img_paths = [line.strip() for line in f if line.strip()]

        with open(attr_file, 'r') as f:
            self.labels = []
            for line in f:
                arr = [float(x) for x in line.strip().split()]
                self.labels.append(arr)

        assert len(self.img_paths) == len(self.labels), "图片数和标签数不一致"
        self.transform = transform

    def __len__(self):
        return len(self.img_paths)

    def __getitem__(self, idx):
        img_path = os.path.join(config.data_root, self.img_paths[idx])
        # 如果只有一个数字，则认为是类别索引，转换为长度26的 one-hot 向量
        if len(self.labels[idx]) == 1:
            onehot = [0.0] * 26
            label_value = int(self.labels[idx][0])
            # 假设标签文件中的类别编号是从1开始的（范围1~26），因此转换为0~25
            label_index = label_value - 1
            # 检查转换后的索引是否在合法范围内
            if label_index < 0 or label_index >= 26:
                raise ValueError(f"转换后的标签索引 {label_index} 超出范围 [0, 25] (原始值: {label_value})")
            onehot[label_index] = 1.0
            label = torch.tensor(onehot, dtype=torch.float32)
        else:
            label = torch.tensor(self.labels[idx], dtype=torch.float32)

        image = Image.open(img_path).convert('RGB')
        if self.transform:
            image = self.transform(image)
        return image, label

#############################
# 5. 统计指标函数：在全局 26 个属性上取 top-k
#############################
def multi_label_top_k_global(outputs, targets, group_splits, k=3):
    """
    参数:
      outputs: (B, 26) logits
      targets: (B, 26) 0/1 标签
      group_splits: 各组属性索引区间
      k: top-k
    返回:
      overall_hits: batch 中预测 top-k 与真实标签有交集的样本数
      group_hits: 各组命中样本数
      total_samples: B
    """
    prob = torch.sigmoid(outputs)
    bsz, nattr = prob.shape
    assert nattr == 26, f"这里仅支持 26 维属性，当前为 {nattr}."

    _, topk_indices = prob.topk(k, dim=1)
    overall_hits = 0
    group_hits = {gname: 0 for gname in group_splits}

    for i in range(bsz):
        true_indices = (targets[i] > 0.5).nonzero(as_tuple=True)[0].tolist()
        pred_indices = topk_indices[i].tolist()
        if len(set(pred_indices) & set(true_indices)) > 0:
            overall_hits += 1
        for gname, intervals in group_splits.items():
            group_attr_indices = []
            for (start, end) in intervals:
                group_attr_indices.extend(range(start, end))
            predicted_in_group = set(pred_indices) & set(group_attr_indices)
            true_in_group = set(true_indices) & set(group_attr_indices)
            if len(predicted_in_group & true_in_group) > 0:
                group_hits[gname] += 1

    return overall_hits, group_hits, bsz

#############################
# 6. 训练和验证流程（增加 top1 指标计算）
#############################
def train_one_epoch(model, loader, criterion, optimizer, device, group_splits):
    model.train()
    total_loss = 0.0
    total_samples = 0

    overall_top1_hit = 0
    overall_top3_hit = 0
    overall_top5_hit = 0

    for images, labels in loader:
        images = images.to(device)
        labels = labels.to(device)

        outputs = model(images)
        loss = criterion(outputs, labels)
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        bs = images.size(0)
        total_loss += loss.item() * bs
        total_samples += bs

        # 计算 top1、top3、top5 准确数
        o_hits1, _, _ = multi_label_top_k_global(outputs, labels, group_splits, k=1)
        o_hits3, _, _ = multi_label_top_k_global(outputs, labels, group_splits, k=3)
        o_hits5, _, _ = multi_label_top_k_global(outputs, labels, group_splits, k=5)

        overall_top1_hit += o_hits1
        overall_top3_hit += o_hits3
        overall_top5_hit += o_hits5

    avg_loss = total_loss / total_samples
    overall_top1_acc = overall_top1_hit / total_samples
    overall_top3_acc = overall_top3_hit / total_samples
    overall_top5_acc = overall_top5_hit / total_samples

    return avg_loss, overall_top1_acc, overall_top3_acc, overall_top5_acc

def validate_or_test_epoch(model, loader, criterion, device, group_splits):
    model.eval()
    total_loss = 0.0
    total_samples = 0

    overall_top1_hit = 0
    overall_top3_hit = 0
    overall_top5_hit = 0

    with torch.no_grad():
        for images, labels in loader:
            images = images.to(device)
            labels = labels.to(device)

            outputs = model(images)
            loss = criterion(outputs, labels)

            bs = images.size(0)
            total_loss += loss.item() * bs
            total_samples += bs

            o_hits1, _, _ = multi_label_top_k_global(outputs, labels, group_splits, k=1)
            o_hits3, _, _ = multi_label_top_k_global(outputs, labels, group_splits, k=3)
            o_hits5, _, _ = multi_label_top_k_global(outputs, labels, group_splits, k=5)

            overall_top1_hit += o_hits1
            overall_top3_hit += o_hits3
            overall_top5_hit += o_hits5

    avg_loss = total_loss / total_samples
    overall_top1_acc = overall_top1_hit / total_samples
    overall_top3_acc = overall_top3_hit / total_samples
    overall_top5_acc = overall_top5_hit / total_samples

    return avg_loss, overall_top1_acc, overall_top3_acc, overall_top5_acc

#############################
# 7. 主训练入口（加入命令行选择、最佳指标跟踪及模型保存）
#############################
if __name__ == "__main__":
    # 设置随机种子
    set_seed(42)

    # 选择数据集
    print('-' * 30)
    dataset_config = {0: "DeepFashion"}
    print("Dataset options:", dataset_config)
    dataset_choice = int(input("Which dataset needs to be trained?\n"))
    dataset_name = dataset_config[dataset_choice]
    print('-' * 30)

    # 选择模型
    model_config = {1: "ResNet50"}
    print("Model options:", model_config)
    model_choice = int(input("Which model needs to be trained?\n"))
    model_name = model_config[model_choice]
    print('-' * 30)

    # 初始化最佳指标跟踪
    best_metrics = {
        'top1': {'acc': 0, 'epoch': 0},
        'top3': {'acc': 0, 'epoch': 0},
        'top5': {'acc': 0, 'epoch': 0}
    }

    # 模型保存路径
    model_save_dir = os.path.join(root_dir, "pretrained", model_name)
    os.makedirs(model_save_dir, exist_ok=True)

    # 构造 Dataset 和 DataLoader
    train_dataset = FashionAttrDataset(Config.train_list, Config.train_labels, train_transform)
    val_dataset = FashionAttrDataset(Config.val_list, Config.val_labels, val_transform)
    test_dataset = FashionAttrDataset(Config.test_list, Config.test_labels, val_transform)

    train_loader = DataLoader(train_dataset, batch_size=Config.batch_size, shuffle=True, num_workers=Config.num_workers)
    val_loader = DataLoader(val_dataset, batch_size=Config.batch_size, shuffle=False, num_workers=Config.num_workers)
    test_loader = DataLoader(test_dataset, batch_size=Config.batch_size, shuffle=False, num_workers=Config.num_workers)

    # 通过 net_maker 选择模型
    model = net_maker[model_name](num_classes=26).to(config.device)

    # 定义损失函数和优化器（多标签预测用 BCEWithLogitsLoss）
    criterion = nn.BCEWithLogitsLoss()
    optimizer = optim.Adam(model.parameters(), lr=Config.lr)

    # 开始训练
    for epoch in range(Config.epochs):
        train_loss, train_top1, train_top3, train_top5 = train_one_epoch(
            model, train_loader, criterion, optimizer, config.device, Config.group_splits
        )
        val_loss, val_top1, val_top3, val_top5 = validate_or_test_epoch(
            model, val_loader, criterion, config.device, Config.group_splits
        )

        # 打印当前 epoch 的结果
        print(f"\nEpoch [{epoch+1}/{Config.epochs}]")
        print(f"  [Train] Loss: {train_loss:.4f} | Top1: {train_top1:.4f} | Top3: {train_top3:.4f} | Top5: {train_top5:.4f}")
        print(f"  [Val  ] Loss: {val_loss:.4f} | Top1: {val_top1:.4f} | Top3: {val_top3:.4f} | Top5: {val_top5:.4f}")

        # 更新并保存表现更好的模型（分别根据 top1、top3、top5 指标）
        if val_top1 > best_metrics['top1']['acc']:
            best_metrics['top1']['acc'] = val_top1
            best_metrics['top1']['epoch'] = epoch + 1
            torch.save(model.state_dict(), os.path.join(model_save_dir, 'best_top1_model.pth'))
            print(f"  >>> Best Top1 model updated at epoch {epoch+1} (Val Top1: {val_top1:.4f})")

        if val_top3 > best_metrics['top3']['acc']:
            best_metrics['top3']['acc'] = val_top3
            best_metrics['top3']['epoch'] = epoch + 1
            torch.save(model.state_dict(), os.path.join(model_save_dir, 'best_top3_model.pth'))
            print(f"  >>> Best Top3 model updated at epoch {epoch+1} (Val Top3: {val_top3:.4f})")

        if val_top5 > best_metrics['top5']['acc']:
            best_metrics['top5']['acc'] = val_top5
            best_metrics['top5']['epoch'] = epoch + 1
            torch.save(model.state_dict(), os.path.join(model_save_dir, 'best_top5_model.pth'))
            print(f"  >>> Best Top5 model updated at epoch {epoch+1} (Val Top5: {val_top5:.4f})")

    print("\nTraining done.")

    # 测试阶段：加载表现最好的 top1 模型进行测试（也可以选择 top3 或 top5 模型）
    print("\n===== Evaluating on Test set with the best Top1 model =====")
    best_model = net_maker[model_name](num_classes=26).to(config.device)
    best_model.load_state_dict(torch.load(os.path.join(model_save_dir, 'best_top1_model.pth')))

    test_loss, test_top1, test_top3, test_top5 = validate_or_test_epoch(
        best_model, test_loader, criterion, config.device, Config.group_splits
    )
    print(f"[Test] Loss: {test_loss:.4f} | Top1: {test_top1:.4f} | Top3: {test_top3:.4f} | Top5: {test_top5:.4f}")
