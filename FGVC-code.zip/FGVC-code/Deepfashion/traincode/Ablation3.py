import os
import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision.models as models

# ------------------------------
# GCI + AFII
# ------------------------------
class GroupInteractionFusion(nn.Module):
    def __init__(self, in_channels, num_groups=4):
        """
        Args:
            in_channels (int): 输入通道数
            num_groups (int): 分组数量
        """
        super(GroupInteractionFusion, self).__init__()
        self.num_groups = num_groups
        self.in_channels = in_channels

        # 特征嵌入，用于计算像素与分组中心的相似度
        self.embedding = nn.Conv2d(in_channels, in_channels, kernel_size=1, bias=False)
        # 可学习的分组中心
        self.group_centers = nn.Parameter(torch.randn(num_groups, in_channels))
        # 分组特征交互模块（此处可作为后续进一步设计的模块）
        self.interaction = nn.Sequential(
            nn.Conv2d(in_channels * num_groups, in_channels, kernel_size=1, bias=False),
            nn.BatchNorm2d(in_channels),
            nn.GELU()
        )
        self.adpavgpool = nn.AdaptiveAvgPool2d(1)
        # 融合映射层
        self.map1 = nn.Conv2d(in_channels * (num_groups + 1), in_channels, 1, 1, 0, bias=True)
        self.drop = nn.Dropout(p=0.5)
        self.map2 = nn.Conv2d(in_channels, in_channels, 1, 1, 0, bias=True)
        self.sigmoid = nn.Sigmoid()
        self.flatten = nn.Flatten()

    def forward(self, x, flag='train'):
        b, c, h, w = x.shape
        if flag in ['train', 'val']:
            # 特征嵌入
            x_embedded = self.embedding(x)  # (b, c, h, w)
            x_flatten = x_embedded.view(b, c, -1).permute(0, 2, 1)  # (b, h*w, c)

            # 计算每个像素与各分组中心的相似度
            group_centers = self.group_centers.unsqueeze(0).expand(b, -1, -1)  # (b, num_groups, c)
            similarity = torch.einsum('bkc,bnc->bkn', group_centers, x_flatten)  # (b, num_groups, h*w)
            similarity = F.softmax(similarity, dim=1)

            # 根据相似度按组加权原始特征；同时将原始特征作为第0组保留
            grouped_features = []  # 列表长度为 num_groups+1，第0个元素为原始特征
            grouped_features.append(x)
            for g in range(self.num_groups):
                weight = similarity[:, g, :].view(b, 1, h, w)
                grouped_features.append(weight * x)

            # 将各组特征堆叠：形状变为 (num_groups+1, b, c, h, w)
            features = torch.stack(grouped_features, dim=0)
            # 交换维度为 (b, num_groups+1, c, h, w)
            features = features.permute(1, 0, 2, 3, 4)

            # 对各组特征做融合：这里采用将所有组的特征展平后进行全局平均池化，然后进行映射
            mutual_features = features.reshape(features.size(0), -1, features.size(3), features.size(4))
            mutual_features = self.adpavgpool(mutual_features)  # (b, c, 1, 1)
            map2_out = self.map1(mutual_features)  # 融合映射（降维再升维）
            map2_out = self.map2(map2_out)

            # 为每个分组生成门控权重，并进行残差融合
            gates = []
            for i in range(self.num_groups + 1):
                gate1 = torch.mul(map2_out, self.adpavgpool(grouped_features[i]))
                gates.append(self.sigmoid(gate1))
            features_all = []
            for i in range(self.num_groups + 1):
                a = torch.mul(gates[i], x) + x
                features_all.append(a)
            # 返回两个信息：
            # grouped_features：原始分组特征列表（包含原始特征）
            # features_all：经过门控融合后的各组特征列表
            return grouped_features, features_all

# ------------------------------
# Transformer Encoder Layer & AIFI模块：基于注意力的尺度内特征交互
# ------------------------------
class TransformerEncoderLayer(nn.Module):
    def __init__(self, c1, cm=2048, num_heads=8, dropout=0.0, act=nn.GELU(), normalize_before=False):
        super().__init__()
        self.ma = nn.MultiheadAttention(c1, num_heads, dropout=dropout, batch_first=True)
        self.fc1 = nn.Linear(c1, cm)
        self.fc2 = nn.Linear(cm, c1)
        self.norm1 = nn.LayerNorm(c1)
        self.norm2 = nn.LayerNorm(c1)
        self.dropout = nn.Dropout(dropout)
        self.dropout1 = nn.Dropout(dropout)
        self.dropout2 = nn.Dropout(dropout)
        self.act = act
        self.normalize_before = normalize_before

    @staticmethod
    def with_pos_embed(tensor, pos=None):
        return tensor if pos is None else tensor + pos

    def forward_post(self, src, src_mask=None, src_key_padding_mask=None, pos=None):
        q = k = self.with_pos_embed(src, pos)
        src2 = self.ma(q, k, value=src, attn_mask=src_mask, key_padding_mask=src_key_padding_mask)[0]
        src = src + self.dropout1(src2)
        src = self.norm1(src)
        src2 = self.fc2(self.dropout(self.act(self.fc1(src))))
        src = src + self.dropout2(src2)
        return self.norm2(src)

    def forward_pre(self, src, src_mask=None, src_key_padding_mask=None, pos=None):
        src2 = self.norm1(src)
        q = k = self.with_pos_embed(src2, pos)
        src2 = self.ma(q, k, value=src2, attn_mask=src_mask, key_padding_mask=src_key_padding_mask)[0]
        src = src + self.dropout1(src2)
        src2 = self.norm2(src)
        src2 = self.fc2(self.dropout(self.act(self.fc1(src2))))
        return src + self.dropout2(src2)

    def forward(self, src, src_mask=None, src_key_padding_mask=None, pos=None):
        if self.normalize_before:
            return self.forward_pre(src, src_mask, src_key_padding_mask, pos)
        return self.forward_post(src, src_mask, src_key_padding_mask, pos)

class AIFI(TransformerEncoderLayer):
    """
    AIFI模块：继承自TransformerEncoderLayer，并在前向过程中添加二维正弦余弦位置编码
    """
    def __init__(self, c1, cm=2048, num_heads=8, dropout=0, act=nn.GELU(), normalize_before=False):
        super().__init__(c1, cm, num_heads, dropout, act, normalize_before)

    def forward(self, x):
        # x形状：[B, C, H, W]
        c, h, w = x.shape[1:]
        pos_embed = self.build_2d_sincos_position_embedding(w, h, c)
        # 将 [B, C, H, W] reshape为 [B, H*W, C]
        x = super().forward(x.flatten(2).permute(0, 2, 1), pos=pos_embed.to(device=x.device, dtype=x.dtype))
        # 还原为 [B, C, H, W]
        return x.permute(0, 2, 1).view([-1, c, h, w]).contiguous()

    @staticmethod
    def build_2d_sincos_position_embedding(w, h, embed_dim=256, temperature=10000.0):
        assert embed_dim % 4 == 0, "Embed dimension must be divisible by 4 for 2D sin-cos position embedding"
        grid_w = torch.arange(w, dtype=torch.float32)
        grid_h = torch.arange(h, dtype=torch.float32)
        grid_w, grid_h = torch.meshgrid(grid_w, grid_h, indexing="ij")
        pos_dim = embed_dim // 4
        omega = torch.arange(pos_dim, dtype=torch.float32) / pos_dim
        omega = 1.0 / (temperature ** omega)
        out_w = grid_w.flatten()[..., None] @ omega[None]
        out_h = grid_h.flatten()[..., None] @ omega[None]
        return torch.cat([torch.sin(out_w), torch.cos(out_w), torch.sin(out_h), torch.cos(out_h)], 1)[None]

# ------------------------------
# Baseline + GCI + AIFI 模型
# ------------------------------
class Net_Baseline_GCI_AIFI(nn.Module):
    def __init__(self, num_classes, num_groups=4, hidden_c=256):
        """
        Args:
            num_classes (int): 分类类别数
            num_groups (int): GCI模块中分组的数量
            hidden_c (int): 投影后特征的通道数（同时也是 AIFI 模块的输入通道数）
        """
        super(Net_Baseline_GCI_AIFI, self).__init__()
        # 载入 ResNet50 骨干
        resnet50 = models.resnet50(weights=None)
        current_dir = os.path.dirname(os.path.abspath(__file__))
        root_dir = os.path.abspath(os.path.join(current_dir, "./"))
        load_path = os.path.join(root_dir, 'pretrained/resnet50.pth')
        state_dict = torch.load(load_path)
        # 删除 fc 层参数，避免类别数不匹配问题
        state_dict.pop('fc.weight', None)
        state_dict.pop('fc.bias', None)
        resnet50.load_state_dict(state_dict, strict=False)
        feas = list(resnet50.children())[:-1]  # 去除最后全连接层
        self.pre_layer = nn.Sequential(*feas[0:4])
        self.stage_1 = nn.Sequential(*feas[4])
        self.stage_2 = nn.Sequential(*feas[5])
        self.stage_3 = nn.Sequential(*feas[6])
        self.stage_4 = nn.Sequential(*feas[7])
        self.avg = feas[8]  # 全局平均池化层
        self.flatten = nn.Flatten()

        # GCI模块：提取分组交互特征（输入通道为 2048）
        self.gci = GroupInteractionFusion(in_channels=2048, num_groups=num_groups)
        # 投影层：将 2048 通道映射到 hidden_c 通道
        self.proj = nn.Sequential(
            nn.Conv2d(2048, hidden_c, kernel_size=1, bias=False),
            nn.BatchNorm2d(hidden_c)
        )
        # AIFI模块：对投影后的特征进行全局尺度内交互（输入通道为 hidden_c）
        self.aifi = AIFI(hidden_c, 1024)
        # 分类器
        self.fc = nn.Linear(hidden_c, num_classes)
        self.drop = nn.Dropout(p=0.5)

    def forward(self, x, flag='train'):
        # Backbone 提取特征
        x = self.pre_layer(x)
        x = self.stage_1(x)
        x = self.stage_2(x)
        x = self.stage_3(x)
        x = self.stage_4(x)

        if flag in ['train', 'val']:
            # 1. 通过 GCI 模块获得分组交互信息
            grouped_features, features_all = self.gci(x, flag=flag)
            # 2. 融合各组特征：这里采用对所有组残差融合结果的平均
            group_cat = torch.stack(features_all, dim=0)  # (num_groups+1, b, c, h, w)
            fused_feature = torch.mean(group_cat, dim=0)    # (b, c, h, w)
            # 3. 投影到低维特征空间
            proj = self.proj(fused_feature)
            # 4. 利用 AIFI 模块进行尺度内全局交互
            p0 = self.aifi(proj)
            # 5. 全局平均池化、展平、Dropout 后接全连接分类器
            p0 = self.flatten(self.avg(p0))
            p0 = self.fc(self.drop(p0))
            return p0

# ------------------------------
# 测试及 FLOPs/参数量计算示例
# ------------------------------
if __name__ == "__main__":
    net = Net_Baseline_GCI_AIFI(num_classes=18, num_groups=4, hidden_c=256).cuda()
    input_tensor = torch.randn(4, 3, 448, 448).cuda()
    x = net(input_tensor)
    print("输出结果形状：", x.shape)

    from thop import profile
    flops, params = profile(net.cuda(), inputs=(input_tensor,))
    print(f"FLOPs: {flops / 1e9:.2f} G")
    print(f"Params: {params / 1e6:.2f} M")
