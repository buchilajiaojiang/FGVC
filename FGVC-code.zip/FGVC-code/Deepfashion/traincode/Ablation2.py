import os
import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision.models as models

# ------------------------------
# GCI + SF
# ------------------------------
class SF(nn.Module):
    def __init__(self, kernel_size=7):
        """
        Args:
            kernel_size (int): 卷积核尺寸，常设置为7。
        """
        super(SF, self).__init__()
        self.conv = nn.Conv2d(2, 1, kernel_size, padding=(kernel_size - 1) // 2, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        # 对输入特征图进行通道平均和最大池化，生成两个单通道图
        avg_out = torch.mean(x, dim=1, keepdim=True)
        max_out, _ = torch.max(x, dim=1, keepdim=True)
        # 拼接后经过卷积和 Sigmoid 得到空间注意力图
        x_cat = torch.cat([avg_out, max_out], dim=1)
        attn = self.sigmoid(self.conv(x_cat))
        # 与原特征相乘，达到选择关键区域的效果
        return x * attn

# ------------------------------
# GCI模块：组聚类交互（GroupInteractionFusion）
# ------------------------------
class GroupInteractionFusion(nn.Module):
    def __init__(self, in_channels, num_groups=4):
        """
        Args:
            in_channels (int): 输入通道数
            num_groups (int): 分组数量
        """
        super(GroupInteractionFusion, self).__init__()
        self.num_groups = num_groups
        self.in_channels = in_channels

        # 特征嵌入，用于计算相似性
        self.embedding = nn.Conv2d(in_channels, in_channels, kernel_size=1, bias=False)
        # 可学习的分组中心初始化
        self.group_centers = nn.Parameter(torch.randn(num_groups, in_channels))
        # 分组特征交互模块
        self.interaction = nn.Sequential(
            nn.Conv2d(in_channels * num_groups, in_channels, kernel_size=1, bias=False),
            nn.BatchNorm2d(in_channels),
            nn.GELU()
        )
        self.adpavgpool = nn.AdaptiveAvgPool2d(1)
        # 映射层用于融合多个组的特征
        self.map1 = nn.Conv2d(in_channels * (num_groups + 1), in_channels, 1, 1, 0, bias=True)
        self.drop = nn.Dropout(p=0.5)
        self.map2 = nn.Conv2d(in_channels, in_channels, 1, 1, 0, bias=True)
        self.sigmoid = nn.Sigmoid()
        self.flatten = nn.Flatten()

    def forward(self, x, flag='train'):
        b, c, h, w = x.shape
        if flag in ['train', 'val']:
            # 特征嵌入与归一化
            x_embedded = self.embedding(x)           # (b, c, h, w)
            x_flatten = x_embedded.view(b, c, -1).permute(0, 2, 1)  # (b, h*w, c)

            # 计算每个像素与各分组中心的相似度
            group_centers = self.group_centers.unsqueeze(0).expand(b, -1, -1)  # (b, num_groups, c)
            similarity = torch.einsum('bkc,bnc->bkn', group_centers, x_flatten)  # (b, num_groups, h*w)
            similarity = F.softmax(similarity, dim=1)

            # 根据相似度按组加权原始特征
            grouped_features = []  # 第0组保存原始特征
            grouped_features.append(x)
            for g in range(self.num_groups):
                weight = similarity[:, g, :].view(b, 1, h, w)
                grouped_features.append(weight * x)
            # stacked shape: (num_groups+1, b, c, h, w)
            features = torch.stack(grouped_features, dim=0)
            features = features.permute(1, 0, 2, 3, 4)  # (b, num_groups+1, c, h, w)

            # 对所有组的特征进行融合：先reshape再全局平均池化
            mutual_features = features.reshape(features.size(0), -1, features.size(3), features.size(4))
            mutual_features = self.adpavgpool(mutual_features)  # (b, c, 1, 1)
            map2_out = self.map1(mutual_features)
            map2_out = self.map2(map2_out)

            # 为每组生成门控权重
            gates = []
            for i in range(self.num_groups + 1):
                gate1 = torch.mul(map2_out, self.adpavgpool(grouped_features[i]))
                gates.append(self.sigmoid(gate1))
            # 使用门控权重进行残差融合
            features_all = []
            for i in range(self.num_groups + 1):
                a = torch.mul(gates[i], x) + x
                features_all.append(a)
            # 返回两个信息：
            # grouped_features: 分组后的特征列表（包含原始特征）
            # features_all: 经过门控融合后的各组特征列表
            return grouped_features, features_all

# ------------------------------
# Baseline + GCI + SF 模型
# ------------------------------
class Net_Baseline_GCI_SF(nn.Module):
    def __init__(self, num_classes, num_groups=4, hidden_c=256):
        """
        Args:
            num_classes (int): 分类类别数
            num_groups (int): GCI模块中分组的数量
            hidden_c (int): 投影后特征的通道数
        """
        super(Net_Baseline_GCI_SF, self).__init__()
        # 载入ResNet50骨干
        resnet50 = models.resnet50(weights=None)
        current_dir = os.path.dirname(os.path.abspath(__file__))
        root_dir = os.path.abspath(os.path.join(current_dir, "./"))
        load_path = os.path.join(root_dir, 'pretrained/resnet50.pth')
        state_dict = torch.load(load_path)
        # 剔除 fc 层参数，避免尺寸不匹配（预训练权重中 fc 层可能输出类别数不一致）
        state_dict.pop('fc.weight', None)
        state_dict.pop('fc.bias', None)
        resnet50.load_state_dict(state_dict, strict=False)
        feas = list(resnet50.children())[:-1]  # 去除最后全连接层
        self.pre_layer = nn.Sequential(*feas[0:4])
        self.stage_1 = nn.Sequential(*feas[4])
        self.stage_2 = nn.Sequential(*feas[5])
        self.stage_3 = nn.Sequential(*feas[6])
        self.stage_4 = nn.Sequential(*feas[7])
        self.avg = feas[8]  # 全局平均池化层
        self.flatten = nn.Flatten()

        # GCI模块：提取分组交互特征
        self.gci = GroupInteractionFusion(in_channels=2048, num_groups=num_groups)
        # SF模块：对融合后的特征进行空间特征选择
        self.sf = SF(kernel_size=7)
        # 投影层：将2048通道映射到 hidden_c 通道
        self.proj = nn.Sequential(
            nn.Conv2d(2048, hidden_c, kernel_size=1, bias=False),
            nn.BatchNorm2d(hidden_c)
        )
        # 分类器
        self.fc = nn.Linear(hidden_c, num_classes)
        self.drop = nn.Dropout(p=0.5)

    def forward(self, x, flag='train'):
        # 使用 ResNet50 骨干提取特征
        x = self.pre_layer(x)
        x = self.stage_1(x)
        x = self.stage_2(x)
        x = self.stage_3(x)
        x = self.stage_4(x)

        if flag in ['train', 'val']:
            # 1. 通过 GCI 模块获得分组交互信息
            grouped_features, features_all = self.gci(x, flag=flag)
            # 对所有组融合后的特征（features_all）进行融合，这里采用平均融合方式
            group_cat = torch.stack(features_all, dim=0)   # shape: (num_groups+1, b, c, h, w)
            fused_feature = torch.mean(group_cat, dim=0)     # shape: (b, c, h, w)
            # 2. 通过 SF 模块进行空间特征选择
            x_sf = self.sf(fused_feature)
            # 3. 投影到低维特征空间
            proj = self.proj(x_sf)
            # 4. 全局平均池化、展平、Dropout 后接全连接分类器
            p0 = self.flatten(self.avg(proj))
            p0 = self.fc(self.drop(p0))
            return p0

# ------------------------------
# 测试及 FLOPs/参数量计算示例
# ------------------------------
if __name__ == "__main__":
    net = Net_Baseline_GCI_SF(num_classes=18, num_groups=4, hidden_c=256).cuda()
    input_tensor = torch.randn(4, 3, 448, 448).cuda()
    x = net(input_tensor)
    print("输出结果形状：", x.shape)

    from thop import profile
    flops, params = profile(net.cuda(), inputs=(input_tensor,))
    print(f"FLOPs: {flops / 1e9:.2f} G")
    print(f"Params: {params / 1e6:.2f} M")
