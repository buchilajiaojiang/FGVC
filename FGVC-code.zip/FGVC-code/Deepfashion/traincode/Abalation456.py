import os
import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision.models as models


# ===================================================
# SF模块：空间特征选择（基于空间注意力）
# ===================================================
class SF(nn.Module):
    def __init__(self, kernel_size=7):
        """
        Args:
            kernel_size (int): 卷积核尺寸，常设置为7。
        """
        super(SF, self).__init__()
        self.conv = nn.Conv2d(2, 1, kernel_size, padding=(kernel_size - 1) // 2, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        # 对输入特征图进行通道方向的平均池化和最大池化
        avg_out = torch.mean(x, dim=1, keepdim=True)
        max_out, _ = torch.max(x, dim=1, keepdim=True)
        # 拼接后通过卷积和 Sigmoid 得到空间注意力图
        x_cat = torch.cat([avg_out, max_out], dim=1)
        attn = self.sigmoid(self.conv(x_cat))
        # 与原特征相乘，起到“选取”关键区域的作用
        return x * attn


# ===================================================
# GCI模块：组聚类交互（Group Interaction Fusion）
# ===================================================
class GroupInteractionFusion(nn.Module):
    def __init__(self, in_channels, num_groups=4):
        """
        Args:
            in_channels (int): 输入通道数
            num_groups (int): 分组数量
        """
        super(GroupInteractionFusion, self).__init__()
        self.num_groups = num_groups
        self.in_channels = in_channels

        # 特征嵌入，用于计算像素与分组中心的相似度
        self.embedding = nn.Conv2d(in_channels, in_channels, kernel_size=1, bias=False)
        # 可学习的分组中心
        self.group_centers = nn.Parameter(torch.randn(num_groups, in_channels))
        # 分组特征交互模块（这里可以进一步设计）
        self.interaction = nn.Sequential(
            nn.Conv2d(in_channels * num_groups, in_channels, kernel_size=1, bias=False),
            nn.BatchNorm2d(in_channels),
            nn.GELU()
        )
        self.adpavgpool = nn.AdaptiveAvgPool2d(1)
        # 融合映射层
        self.map1 = nn.Conv2d(in_channels * (num_groups + 1), in_channels, 1, bias=True)
        self.drop = nn.Dropout(p=0.5)
        self.map2 = nn.Conv2d(in_channels, in_channels, 1, bias=True)
        self.sigmoid = nn.Sigmoid()
        self.flatten = nn.Flatten()

    def forward(self, x, flag='train'):
        b, c, h, w = x.shape
        if flag in ['train', 'val']:
            # 特征嵌入
            x_embedded = self.embedding(x)  # (b, c, h, w)
            x_flatten = x_embedded.view(b, c, -1).permute(0, 2, 1)  # (b, h*w, c)
            # 计算每个像素与各分组中心的相似度
            group_centers = self.group_centers.unsqueeze(0).expand(b, -1, -1)  # (b, num_groups, c)
            similarity = torch.einsum('bkc,bnc->bkn', group_centers, x_flatten)  # (b, num_groups, h*w)
            similarity = F.softmax(similarity, dim=1)
            # 根据相似度为每个分组加权原始特征，另外将原始特征作为第0组保留
            grouped_features = []  # 长度为 num_groups+1
            grouped_features.append(x)
            for g in range(self.num_groups):
                weight = similarity[:, g, :].view(b, 1, h, w)
                grouped_features.append(weight * x)
            # 将各组特征堆叠，并交换维度为 (b, num_groups+1, c, h, w)
            features = torch.stack(grouped_features, dim=0).permute(1, 0, 2, 3, 4)
            # 对各组特征融合：先 reshape 后全局平均池化
            mutual_features = features.reshape(b, -1, h, w)
            mutual_features = self.adpavgpool(mutual_features)  # (b, c, 1, 1)
            map2_out = self.map1(mutual_features)
            map2_out = self.map2(map2_out)
            # 为每个分组生成门控权重并进行残差融合
            gates = []
            for i in range(self.num_groups + 1):
                gate1 = torch.mul(map2_out, self.adpavgpool(grouped_features[i]))
                gates.append(self.sigmoid(gate1))
            features_all = []
            for i in range(self.num_groups + 1):
                a = torch.mul(gates[i], x) + x
                features_all.append(a)
            return grouped_features, features_all
        else:
            return x


# ===================================================
# AIFI模块：基于注意力的尺度内特征交互
# ===================================================
class TransformerEncoderLayer(nn.Module):
    def __init__(self, c1, cm=2048, num_heads=8, dropout=0.0, act=nn.GELU(), normalize_before=False):
        super().__init__()
        self.ma = nn.MultiheadAttention(c1, num_heads, dropout=dropout, batch_first=True)
        self.fc1 = nn.Linear(c1, cm)
        self.fc2 = nn.Linear(cm, c1)
        self.norm1 = nn.LayerNorm(c1)
        self.norm2 = nn.LayerNorm(c1)
        self.dropout = nn.Dropout(dropout)
        self.dropout1 = nn.Dropout(dropout)
        self.dropout2 = nn.Dropout(dropout)
        self.act = act
        self.normalize_before = normalize_before

    @staticmethod
    def with_pos_embed(tensor, pos=None):
        return tensor if pos is None else tensor + pos

    def forward_post(self, src, src_mask=None, src_key_padding_mask=None, pos=None):
        q = k = self.with_pos_embed(src, pos)
        src2 = self.ma(q, k, value=src, attn_mask=src_mask, key_padding_mask=src_key_padding_mask)[0]
        src = src + self.dropout1(src2)
        src = self.norm1(src)
        src2 = self.fc2(self.dropout(self.act(self.fc1(src))))
        src = src + self.dropout2(src2)
        return self.norm2(src)

    def forward_pre(self, src, src_mask=None, src_key_padding_mask=None, pos=None):
        src2 = self.norm1(src)
        q = k = self.with_pos_embed(src2, pos)
        src2 = self.ma(q, k, value=src2, attn_mask=src_mask, key_padding_mask=src_key_padding_mask)[0]
        src = src + self.dropout1(src2)
        src2 = self.norm2(src)
        src2 = self.fc2(self.dropout(self.act(self.fc1(src2))))
        return src + self.dropout2(src2)

    def forward(self, src, src_mask=None, src_key_padding_mask=None, pos=None):
        if self.normalize_before:
            return self.forward_pre(src, src_mask, src_key_padding_mask, pos)
        return self.forward_post(src, src_mask, src_key_padding_mask, pos)


class AIFI(TransformerEncoderLayer):
    def __init__(self, c1, cm=2048, num_heads=8, dropout=0, act=nn.GELU(), normalize_before=False):
        super().__init__(c1, cm, num_heads, dropout, act, normalize_before)

    def forward(self, x):
        # x: [B, C, H, W]
        c, h, w = x.shape[1:]
        pos_embed = self.build_2d_sincos_position_embedding(w, h, c)
        # reshape为 [B, H*W, C]
        x = super().forward(x.flatten(2).permute(0, 2, 1), pos=pos_embed.to(device=x.device, dtype=x.dtype))
        # 还原为 [B, C, H, W]
        return x.permute(0, 2, 1).view([-1, c, h, w]).contiguous()

    @staticmethod
    def build_2d_sincos_position_embedding(w, h, embed_dim=256, temperature=10000.0):
        assert embed_dim % 4 == 0, "Embed dimension must be divisible by 4 for 2D sin-cos position embedding"
        grid_w = torch.arange(w, dtype=torch.float32)
        grid_h = torch.arange(h, dtype=torch.float32)
        grid_w, grid_h = torch.meshgrid(grid_w, grid_h, indexing="ij")
        pos_dim = embed_dim // 4
        omega = torch.arange(pos_dim, dtype=torch.float32) / pos_dim
        omega = 1.0 / (temperature ** omega)
        out_w = grid_w.flatten()[..., None] @ omega[None]
        out_h = grid_h.flatten()[..., None] @ omega[None]
        return torch.cat([torch.sin(out_w), torch.cos(out_w), torch.sin(out_h), torch.cos(out_h)], 1)[None]


# ===================================================
# Baseline + GCI 模型
# ===================================================
class Net_Baseline_GCI(nn.Module):
    def __init__(self, num_classes, num_groups=4, hidden_c=256):
        """
        Args:
            num_classes (int): 分类类别数
            num_groups (int): GCI模块中分组数量
            hidden_c (int): 投影后特征通道数
        """
        super(Net_Baseline_GCI, self).__init__()
        # 载入 ResNet50 骨干
        resnet50 = models.resnet50(weights=None)
        current_dir = os.path.dirname(os.path.abspath(__file__))
        root_dir = os.path.abspath(os.path.join(current_dir, "./"))
        load_path = os.path.join(root_dir, 'pretrained/resnet50.pth')
        state_dict = torch.load(load_path)
        # 删除 fc 层参数，避免类别数不匹配
        state_dict.pop('fc.weight', None)
        state_dict.pop('fc.bias', None)
        resnet50.load_state_dict(state_dict, strict=False)
        feas = list(resnet50.children())[:-1]  # 去除最后 fc 层
        self.pre_layer = nn.Sequential(*feas[0:4])
        self.stage_1 = nn.Sequential(*feas[4])
        self.stage_2 = nn.Sequential(*feas[5])
        self.stage_3 = nn.Sequential(*feas[6])
        self.stage_4 = nn.Sequential(*feas[7])
        self.avg = feas[8]
        self.flatten = nn.Flatten()
        # GCI 模块（输入通道为 2048）
        self.gci = GroupInteractionFusion(in_channels=2048, num_groups=num_groups)
        # 投影层，将 2048 通道映射到 hidden_c 通道
        self.proj = nn.Sequential(
            nn.Conv2d(2048, hidden_c, kernel_size=1, bias=False),
            nn.BatchNorm2d(hidden_c)
        )
        self.fc = nn.Linear(hidden_c, num_classes)
        self.drop = nn.Dropout(p=0.5)

    def forward(self, x, flag='train'):
        # Backbone 特征提取
        x = self.pre_layer(x)
        x = self.stage_1(x)
        x = self.stage_2(x)
        x = self.stage_3(x)
        x = self.stage_4(x)
        # 通过 GCI 模块获得分组交互特征
        grouped_features, features_all = self.gci(x, flag=flag)
        # 这里采用对所有组融合后的残差结果取平均
        group_cat = torch.stack(features_all, dim=0)  # shape: (num_groups+1, b, c, h, w)
        fused_feature = torch.mean(group_cat, dim=0)  # shape: (b, c, h, w)
        proj = self.proj(fused_feature)
        p0 = self.flatten(self.avg(proj))
        p0 = self.fc(self.drop(p0))
        return p0


# ===================================================
# Baseline + SF 模型
# ===================================================
class Net_Baseline_SF(nn.Module):
    def __init__(self, num_classes, hidden_c=256):
        """
        Args:
            num_classes (int): 分类类别数
            hidden_c (int): 投影后特征通道数
        """
        super(Net_Baseline_SF, self).__init__()
        resnet50 = models.resnet50(weights=None)
        current_dir = os.path.dirname(os.path.abspath(__file__))
        root_dir = os.path.abspath(os.path.join(current_dir, "./"))
        load_path = os.path.join(root_dir, 'pretrained/resnet50.pth')
        state_dict = torch.load(load_path)
        state_dict.pop('fc.weight', None)
        state_dict.pop('fc.bias', None)
        resnet50.load_state_dict(state_dict, strict=False)
        feas = list(resnet50.children())[:-1]
        self.pre_layer = nn.Sequential(*feas[0:4])
        self.stage_1 = nn.Sequential(*feas[4])
        self.stage_2 = nn.Sequential(*feas[5])
        self.stage_3 = nn.Sequential(*feas[6])
        self.stage_4 = nn.Sequential(*feas[7])
        self.avg = feas[8]
        self.flatten = nn.Flatten()
        # SF 模块
        self.sf = SF(kernel_size=7)
        self.proj = nn.Sequential(
            nn.Conv2d(2048, hidden_c, kernel_size=1, bias=False),
            nn.BatchNorm2d(hidden_c)
        )
        self.fc = nn.Linear(hidden_c, num_classes)
        self.drop = nn.Dropout(p=0.5)

    def forward(self, x, flag='train'):
        x = self.pre_layer(x)
        x = self.stage_1(x)
        x = self.stage_2(x)
        x = self.stage_3(x)
        x = self.stage_4(x)
        x_sf = self.sf(x)
        proj = self.proj(x_sf)
        p0 = self.flatten(self.avg(proj))
        p0 = self.fc(self.drop(p0))
        return p0


# ===================================================
# Baseline + AIFI 模型
# ===================================================
class Net_Baseline_AIFI(nn.Module):
    def __init__(self, num_classes, hidden_c=256):
        """
        Args:
            num_classes (int): 分类类别数
            hidden_c (int): 投影后特征通道数，同时也是 AIFI 模块的输入通道数
        """
        super(Net_Baseline_AIFI, self).__init__()
        resnet50 = models.resnet50(weights=None)
        current_dir = os.path.dirname(os.path.abspath(__file__))
        root_dir = os.path.abspath(os.path.join(current_dir, "./"))
        load_path = os.path.join(root_dir, 'pretrained/resnet50.pth')
        state_dict = torch.load(load_path)
        state_dict.pop('fc.weight', None)
        state_dict.pop('fc.bias', None)
        resnet50.load_state_dict(state_dict, strict=False)
        feas = list(resnet50.children())[:-1]
        self.pre_layer = nn.Sequential(*feas[0:4])
        self.stage_1 = nn.Sequential(*feas[4])
        self.stage_2 = nn.Sequential(*feas[5])
        self.stage_3 = nn.Sequential(*feas[6])
        self.stage_4 = nn.Sequential(*feas[7])
        self.avg = feas[8]
        self.flatten = nn.Flatten()
        # 投影层：将 2048 通道映射到 hidden_c
        self.proj = nn.Sequential(
            nn.Conv2d(2048, hidden_c, kernel_size=1, bias=False),
            nn.BatchNorm2d(hidden_c)
        )
        # AIFI 模块
        self.aifi = AIFI(hidden_c, 1024)
        self.fc = nn.Linear(hidden_c, num_classes)
        self.drop = nn.Dropout(p=0.5)

    def forward(self, x, flag='train'):
        x = self.pre_layer(x)
        x = self.stage_1(x)
        x = self.stage_2(x)
        x = self.stage_3(x)
        x = self.stage_4(x)
        proj = self.proj(x)
        p0 = self.aifi(proj)
        p0 = self.flatten(self.avg(p0))
        p0 = self.fc(self.drop(p0))
        return p0


# ===================================================
# 测试及 FLOPs/参数量计算示例
# ===================================================
if __name__ == "__main__":
    # 根据需要选择测试变体
    net_gci = Net_Baseline_GCI(num_classes=18, num_groups=4, hidden_c=256).cuda()
    net_sf = Net_Baseline_SF(num_classes=18, hidden_c=256).cuda()
    net_aifi = Net_Baseline_AIFI(num_classes=18, hidden_c=256).cuda()

    input_tensor = torch.randn(4, 3, 448, 448).cuda()

    x_gci = net_gci(input_tensor)
    x_sf = net_sf(input_tensor)
    x_aifi = net_aifi(input_tensor)

    print("Baseline+GCI 输出形状：", x_gci.shape)
    print("Baseline+SF 输出形状：", x_sf.shape)
    print("Baseline+AIFI 输出形状：", x_aifi.shape)

    from thop import profile

    flops_gci, params_gci = profile(net_gci.cuda(), inputs=(input_tensor,))
    flops_sf, params_sf = profile(net_sf.cuda(), inputs=(input_tensor,))
    flops_aifi, params_aifi = profile(net_aifi.cuda(), inputs=(input_tensor,))

    print(f"Baseline+GCI: FLOPs: {flops_gci / 1e9:.2f} G, Params: {params_gci / 1e6:.2f} M")
    print(f"Baseline+SF:  FLOPs: {flops_sf / 1e9:.2f} G, Params: {params_sf / 1e6:.2f} M")
    print(f"Baseline+AIFI: FLOPs: {flops_aifi / 1e9:.2f} G, Params: {params_aifi / 1e6:.2f} M")

    #Baseline+GCI: FLOPs: 69.92 G, Params: 53.40 M
    #Baseline+SF:  FLOPs: 66.52 G, Params: 24.04 M
    #Baseline+AIFI: FLOPs: 66.93 G, Params: 24.56 M
