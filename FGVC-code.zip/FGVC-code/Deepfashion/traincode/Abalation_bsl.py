# models.py
import torch
import torch.nn as nn
import torchvision.models as models
import os

current_dir = os.path.dirname(os.path.abspath(__file__))
root_dir = os.path.abspath(os.path.join(current_dir, "./"))

class ResNet50(nn.Module):
    def __init__(self, num_classes):
        super(ResNet50, self).__init__()
        # 初始化一个标准的 ResNet50 模型（默认fc层输出1000类）
        self.resnet50 = models.resnet50(weights=None)
        load_path = os.path.join(root_dir, 'pretrained/resnet50.pth')

        # 加载检查点
        checkpoint = torch.load(load_path, weights_only=True)
        # 过滤掉fc层的参数（检查点中的fc层参数对应的是26个类别）
        filtered_checkpoint = {k: v for k, v in checkpoint.items() if not k.startswith("fc.")}
        # 只加载匹配的参数，忽略fc层（使用strict=False）
        self.resnet50.load_state_dict(filtered_checkpoint, strict=False)


        # 提取除最后fc层外的所有子模块
        feas = list(self.resnet50.children())[:-1]
        self.conv_layers = nn.Sequential(*feas)
        self.flatten = nn.Flatten()
        # 定义新的全连接层，将输出类别数设置为所需的num_classes
        self.linear = nn.Linear(2048, num_classes)

    def forward(self, x):
        x = self.conv_layers(x)
        x = self.flatten(x)
        x = self.linear(x)
        return x

if __name__ == '__main__':
    # 测试模型
    img = torch.randn(4, 3, 448, 448)
    net = ResNet50(num_classes=18)
    print(net)
    print(net(img).shape)
