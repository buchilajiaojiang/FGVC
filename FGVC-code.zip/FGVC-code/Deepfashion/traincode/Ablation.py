import os
import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision.models as models

# ------------------------------
# SF+ AI FI
# ------------------------------
class SF(nn.Module):
    def __init__(self, kernel_size=7):
        super(SF, self).__init__()
        self.conv = nn.Conv2d(2, 1, kernel_size, padding=(kernel_size - 1) // 2, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        avg_out = torch.mean(x, dim=1, keepdim=True)
        max_out, _ = torch.max(x, dim=1, keepdim=True)
        x_cat = torch.cat([avg_out, max_out], dim=1)
        attn = self.sigmoid(self.conv(x_cat))
        return x * attn

# ------------------------------
# Transformer Encoder Layer & AIFI模块
# ------------------------------
class TransformerEncoderLayer(nn.Module):
    def __init__(self, c1, cm=2048, num_heads=8, dropout=0.0, act=nn.GELU(), normalize_before=False):
        super().__init__()
        self.ma = nn.MultiheadAttention(c1, num_heads, dropout=dropout, batch_first=True)
        self.fc1 = nn.Linear(c1, cm)
        self.fc2 = nn.Linear(cm, c1)
        self.norm1 = nn.LayerNorm(c1)
        self.norm2 = nn.LayerNorm(c1)
        self.dropout = nn.Dropout(dropout)
        self.dropout1 = nn.Dropout(dropout)
        self.dropout2 = nn.Dropout(dropout)
        self.act = act
        self.normalize_before = normalize_before

    @staticmethod
    def with_pos_embed(tensor, pos=None):
        return tensor if pos is None else tensor + pos

    def forward_post(self, src, src_mask=None, src_key_padding_mask=None, pos=None):
        q = k = self.with_pos_embed(src, pos)
        src2 = self.ma(q, k, value=src, attn_mask=src_mask, key_padding_mask=src_key_padding_mask)[0]
        src = src + self.dropout1(src2)
        src = self.norm1(src)
        src2 = self.fc2(self.dropout(self.act(self.fc1(src))))
        src = src + self.dropout2(src2)
        return self.norm2(src)

    def forward_pre(self, src, src_mask=None, src_key_padding_mask=None, pos=None):
        src2 = self.norm1(src)
        q = k = self.with_pos_embed(src2, pos)
        src2 = self.ma(q, k, value=src2, attn_mask=src_mask, key_padding_mask=src_key_padding_mask)[0]
        src = src + self.dropout1(src2)
        src2 = self.norm2(src)
        src2 = self.fc2(self.dropout(self.act(self.fc1(src2))))
        return src + self.dropout2(src2)

    def forward(self, src, src_mask=None, src_key_padding_mask=None, pos=None):
        if self.normalize_before:
            return self.forward_pre(src, src_mask, src_key_padding_mask, pos)
        return self.forward_post(src, src_mask, src_key_padding_mask, pos)

class AIFI(TransformerEncoderLayer):
    def __init__(self, c1, cm=2048, num_heads=8, dropout=0, act=nn.GELU(), normalize_before=False):
        super().__init__(c1, cm, num_heads, dropout, act, normalize_before)

    def forward(self, x):
        c, h, w = x.shape[1:]
        pos_embed = self.build_2d_sincos_position_embedding(w, h, c)
        x = super().forward(x.flatten(2).permute(0, 2, 1), pos=pos_embed.to(device=x.device, dtype=x.dtype))
        return x.permute(0, 2, 1).view([-1, c, h, w]).contiguous()

    @staticmethod
    def build_2d_sincos_position_embedding(w, h, embed_dim=256, temperature=10000.0):
        assert embed_dim % 4 == 0, "Embed dimension must be divisible by 4 for 2D sin-cos position embedding"
        grid_w = torch.arange(w, dtype=torch.float32)
        grid_h = torch.arange(h, dtype=torch.float32)
        grid_w, grid_h = torch.meshgrid(grid_w, grid_h, indexing="ij")
        pos_dim = embed_dim // 4
        omega = torch.arange(pos_dim, dtype=torch.float32) / pos_dim
        omega = 1.0 / (temperature ** omega)
        out_w = grid_w.flatten()[..., None] @ omega[None]
        out_h = grid_h.flatten()[..., None] @ omega[None]
        return torch.cat([torch.sin(out_w), torch.cos(out_w), torch.sin(out_h), torch.cos(out_h)], 1)[None]

# ------------------------------
# Baseline + SF + AIFI 模型
# ------------------------------
class Net_Baseline_SF_AIFI(nn.Module):
    def __init__(self, num_classes, hidden_c=256):
        super(Net_Baseline_SF_AIFI, self).__init__()
        # 载入ResNet50骨干
        resnet50 = models.resnet50(weights=None)
        current_dir = os.path.dirname(os.path.abspath(__file__))
        root_dir = os.path.abspath(os.path.join(current_dir, "./"))
        load_path = os.path.join(root_dir, 'pretrained/resnet50.pth')
        state_dict = torch.load(load_path)
        # 删除fc层参数，避免尺寸不匹配
        state_dict.pop('fc.weight', None)
        state_dict.pop('fc.bias', None)
        resnet50.load_state_dict(state_dict, strict=False)
        feas = list(resnet50.children())[:-1]  # 去除最后的全连接层
        self.pre_layer = nn.Sequential(*feas[0:4])
        self.stage_1 = nn.Sequential(*feas[4])
        self.stage_2 = nn.Sequential(*feas[5])
        self.stage_3 = nn.Sequential(*feas[6])
        self.stage_4 = nn.Sequential(*feas[7])
        self.avg = feas[8]
        self.flatten = nn.Flatten()

        # SF模块：进行空间特征选择
        self.sf = SF(kernel_size=7)

        # 投影层：将2048通道映射到hidden_c通道
        self.proj = nn.Sequential(
            nn.Conv2d(2048, hidden_c, kernel_size=1, bias=False),
            nn.BatchNorm2d(hidden_c)
        )

        # AIFI模块：基于Transformer的尺度内特征交互
        self.aifi = AIFI(hidden_c, 1024)

        # 分类器
        self.fc = nn.Linear(hidden_c, num_classes)
        self.drop = nn.Dropout(p=0.5)

    def forward(self, x, flag='train'):
        x = self.pre_layer(x)
        x = self.stage_1(x)
        x = self.stage_2(x)
        x = self.stage_3(x)
        x = self.stage_4(x)

        if flag in ['train', 'val']:
            x_sf = self.sf(x)
            proj = self.proj(x_sf)
            p0 = self.aifi(proj)
            p0 = self.flatten(self.avg(p0))
            p0 = self.fc(self.drop(p0))
            return p0

if __name__ == "__main__":
    net = Net_Baseline_SF_AIFI(num_classes=18).cuda()
    input_tensor = torch.randn(4, 3, 448, 448).cuda()
    x = net(input_tensor)
    print("输出结果形状：", x.shape)

    # 使用thop工具计算FLOPs和参数量
    from thop import profile
    flops, params = profile(net.cuda(), inputs=(input_tensor,))
    print(f"FLOPs: {flops / 1e9:.2f} G")
    print(f"Params: {params / 1e6:.2f} M")
